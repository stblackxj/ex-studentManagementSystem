create table t_student (
id int(10),
name varchar(20),
age int(10),
sex varchar(2)
);
select * from t_student ;
delete FROM t_student where id =22;