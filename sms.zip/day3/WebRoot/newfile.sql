select * from t_student;
