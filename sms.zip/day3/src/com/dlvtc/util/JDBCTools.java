package com.dlvtc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCTools {
	private static String username =null;
	private static String password  =null;
	private static String url =null;
	private static String driverClass =null;
	
	static{
		username ="root";
		password ="root";
		//url="jdbc:mysql:/localhost:3306/mysql";
		url = "jdbc:mysql://localhost:3306/mysql";
		driverClass="com.mysql.jdbc.Driver";
		try{
			Class.forName(driverClass);
			
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}		
	}
	//��ȡ����
	public static Connection getConnection(){
		Connection conn =null;
		try{
			conn = DriverManager.getConnection(url,username,password);
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return conn;
		
				
	}
	//�ر�����
	public static void closeConnection(Connection conn,PreparedStatement ps,ResultSet rs){
		try{
			if(conn !=null)
				conn.close();
			if(ps !=null)
				ps.close();
			if(rs !=null)
				rs.close();
			
		}catch (SQLException e){
			e.printStackTrace();
		}
		
	}
	public static void main (String[] args){
		System.out.println(getConnection());
	}

	
}
