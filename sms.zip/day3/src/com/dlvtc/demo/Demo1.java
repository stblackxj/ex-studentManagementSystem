package com.dlvtc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Demo1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url ="jdbc:mysql://localhost:3306/mysql";
		Connection conn =DriverManager.getConnection(url,"root","root");
		//System.out.println(conn);
		
		String sql ="INSERT INTO t_student(id,name,age,sex) VALUES(?,?,?,?)";
		
		PreparedStatement ps =conn.prepareStatement(sql);
		ps.setInt(1, 2);
		ps.setString(2, "xiaoliww");
		ps.setInt(3, 12);
		ps.setString(4, "M");
		
		int flag =ps.executeUpdate();
		if(flag >0)
			System.out.println("add true");
		else 
			System.out.println("add failure");
		
		conn.close();
		
		

	}

}
