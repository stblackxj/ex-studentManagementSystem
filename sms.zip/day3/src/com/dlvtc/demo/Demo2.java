package com.dlvtc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Demo2 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url ="jdbc:mysql://localhost:3306/mysql";
		Connection conn =DriverManager.getConnection(url,"root","root");
		//System.out.println(conn);
		
		String sql ="select id,name,age,sex from t_student";
		PreparedStatement ps =conn.prepareStatement(sql);
		ResultSet rs =ps.executeQuery();
		while(rs.next()){
			int id =rs.getInt("id");
			String name =rs.getString("name");
			int age =rs.getInt("age");
			String sex =rs.getString("sex");
			System.out.println("id: "+id + "\tname:"+ name +"\tage:" + age +"\tsex:" + sex );
		
		}
		conn.close();

	}

}
