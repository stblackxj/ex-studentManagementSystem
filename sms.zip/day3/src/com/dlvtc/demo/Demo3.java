package com.dlvtc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Demo3 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url ="jdbc:mysql://localhost:3306/mysql";
		Connection conn =DriverManager.getConnection(url,"root","root");
		//System.out.println(conn);
		
		String sql ="delete FROM t_student where id =?";
		PreparedStatement ps =conn.prepareStatement(sql);
		ps.setInt(1,2);
		int flag =ps.executeUpdate();
		if (flag > 0)
			System.out.println("delete success");
		else 
			System.out.println("delete fail");
		conn.close();
			
		
		
		
	
	}

}
