package com.dlvtc.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class Demo4 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url ="jdbc:mysql://localhost:3306/mysql";
		//String url ="jdbc:mysql://localhost:3306/mysql";
		Connection conn =DriverManager.getConnection(url,"root","root");
		
		String sql ="update t_student set name =? ,age =? where id =?";
		PreparedStatement ps =conn.prepareStatement(sql);
		ps.setString(1, "xiahong");
		ps.setInt(2, 15);
		ps.setInt(3, 1);
		int flag =ps.executeUpdate();
		if (flag > 0)
			System.out.println("update success");
		else 
			System.out.println("update fail");
		conn.close();


	}

}
