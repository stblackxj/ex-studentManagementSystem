package com.dlvtc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dlsp.pojo.Student;
import com.dlvtc.util.JDBCTools;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

public class StudentDao {
	//����
	public void addStudent(Student student){
		Connection conn = null;
		PreparedStatement ps =null;
		try{
			conn = JDBCTools.getConnection();
			String sql ="INSERT INTO t_student(id,name,age,sex) VALUES(?,?,?,?)";
			
			ps =conn.prepareStatement(sql);
			ps.setInt(1, student.getId());
			ps.setString(2, student.getName());
			ps.setInt(3, student.getAge());
			ps.setString(4, student.getSex());
			ps.executeUpdate();
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			JDBCTools.closeConnection(conn, ps, null);
		}
		
	}
	//ɾ��
	public void deleteStudent(int id ){
		Connection conn = null;
		PreparedStatement ps =null;
		try{
			conn = JDBCTools.getConnection();
			String sql ="DELETE FROM t_student WHERE id =?";
			
			ps =conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			JDBCTools.closeConnection(conn, ps, null);
		}
	}
	
	//�޸�
	public void updateStudent(Student student){
		Connection conn = null;
		PreparedStatement ps =null;
		try{
			conn = JDBCTools.getConnection();
			String sql ="UPDATE t_student SET name=? ,age=? ,sex=? WHERE id=?";
			
			ps =conn.prepareStatement(sql);
			ps.setString(1, student.getName());
			ps.setInt(2, student.getAge());
			ps.setString(3, student.getSex());
			ps.setInt(4, student.getId());
			ps.executeUpdate();
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			JDBCTools.closeConnection(conn, ps, null);
		}
	}
		

	//��ѯid
	public Student  findById(int id){
		Connection conn = null;
		PreparedStatement ps =null;
		ResultSet rs =null;
		try{
			conn = JDBCTools.getConnection();
			String sql ="SELECT id,name,age,sex FROM t_student WHERE id=? ";
			
			ps =conn.prepareStatement(sql);
			ps.setInt(1, id);
			rs =ps.executeQuery();
			Student student =null;
			while(rs.next()){
				int stuId=rs.getInt("id");
				String name=rs.getString("name");
				int age =rs.getInt("age");
				String sex =rs.getString("sex");
				student =new Student(stuId , name , sex , age);
				return student;
			}
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			JDBCTools.closeConnection(conn, ps, null);
		}
		return null;
		
	}
	
	
	
	public List<Student> findAll(){
		Connection conn = null;
		PreparedStatement ps =null;
		ResultSet rs =null;
		try{
			conn = JDBCTools.getConnection();
			String sql ="SELECT id,name,age,sex FROM t_student ";
			
			ps =conn.prepareStatement(sql);
			rs =ps.executeQuery();
			Student student =null;
			List<Student> list =new ArrayList<Student>();
			while(rs.next()){
				int stuId=rs.getInt("id");
				String name=rs.getString("name");
				int age =rs.getInt("age");
				String sex =rs.getString("sex");
				student =new Student(stuId , name , sex , age);
				list.add(student);
			}
			return list;
		}catch (SQLException e){
			e.printStackTrace();
		}finally{
			JDBCTools.closeConnection(conn, ps, null);
		}
		
		return null;
		
	}

	//��ѯ
	
	

}
