package com.dlvtc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlsp.pojo.Student;
import com.dlvtc.dao.StudentDao;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/student/*")
public class StudentServlet extends HttpServlet {
	
	private StudentDao studentDao;
	
    public StudentServlet() {
        studentDao =new StudentDao();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		//��ȡ��ַ���ĵ�ַ
		String uri =request.getRequestURI();
		uri =uri.substring(uri.lastIndexOf("/") +1);
		
		//�ж϶�Ӧ������
		if(uri.equals("listStudent")){
			//��ʾ���е����ݲ���
			
		
		
		List<Student> list =studentDao.findAll();
		
		request.setAttribute("list", list);
	
		request.getRequestDispatcher("/student.jsp").forward(request, response);
		}else if(uri.equals("addStudent")){
			//���Ӳ���
			//ͨ��id��ȡ�ı����ֵ
			//���ַ�ת������������
			int id =Integer.parseInt(request.getParameter("id"));
			String name =request.getParameter("name");
			String sex =request.getParameter("sex");			
			int age =Integer.parseInt(request.getParameter("age"));
			Student student =new Student( id,name,sex,age);
			//���ӵķ���
			studentDao.addStudent(student);
			//�ض���listStudent
			response.sendRedirect("listStudent");
			
			
		}else if(uri.equals("deleteStudent")){
			//��ȡҪɾ����id
			int id =Integer.parseInt(request.getParameter("id"));
			studentDao.deleteStudent(id);
			response.sendRedirect("listStudent");
		}else if (uri.equals("loadStudent")){
			//load() �����ӷ�������������
			int id =Integer.parseInt(request.getParameter("id"));
			Student student =studentDao.findById(id);
			request.setAttribute("student", student);
			request.getRequestDispatcher("/loadStudent.jsp").forward(request, response);
		}else if(uri.equals("updateStudent")) {
			int id =Integer.parseInt(request.getParameter("id"));
			String name =request.getParameter("name");
			int age =Integer.parseInt(request.getParameter("age"));
			String sex =request.getParameter("sex");
			Student student =new Student(id,name,sex,age);
			studentDao.updateStudent(student);
			response.sendRedirect("listStudent");
			
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
