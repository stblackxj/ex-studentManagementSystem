create table t_goods (
goodsId int(10),
goodsName varchar(20),
goodsAmount int(10),
goodsPrice int(10),
goodsAdd varchar(50)
);
select * from t_goods ;
delete FROM t_goods where id =22;