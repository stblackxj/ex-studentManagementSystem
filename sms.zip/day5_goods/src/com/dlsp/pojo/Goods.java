package com.dlsp.pojo;

public class Goods {
	private int goodsId;
	private String  goodsName;
	private int goodsAmount;
	private int goodsPrice;
	private String goodsAdd;
	public int getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public int getGoodsAmount() {
		return goodsAmount;
	}
	public void setGoodsAmount(int goodsAmount) {
		this.goodsAmount = goodsAmount;
	}
	public int getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(int goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	public String getGoodsAdd() {
		return goodsAdd;
	}
	public void setGoodsAdd(String goodsAdd) {
		this.goodsAdd = goodsAdd;
	}
	public Goods(int goodsId, String goodsName, int goodsAmount,
			int goodsPrice, String goodsAdd) {
		super();
		this.goodsId = goodsId;
		this.goodsName = goodsName;
		this.goodsAmount = goodsAmount;
		this.goodsPrice = goodsPrice;
		this.goodsAdd = goodsAdd;
	}
	public Goods() {
		super();
	}
	
	

}
