package com.dlvtc.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dlsp.pojo.Goods;
import com.dlvtc.dao.GoodsDao;



/**
 * Servlet implementation class GoodsServlet
 */
@WebServlet("/goods/*")
public class GoodsServlet extends HttpServlet {
	
	private GoodsDao goodsDao;
	
    public GoodsServlet() {
    	goodsDao =new GoodsDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		//��ȡ��ַ���ĵ�ַ
		String uri =request.getRequestURI();
		uri =uri.substring(uri.lastIndexOf("/") +1);
		
		//�ж϶�Ӧ������
		if(uri.equals("listGoods")){
			//��ʾ���е����ݲ���
			
		
		
		List<Goods> list =goodsDao.findAll();
		
		request.setAttribute("list", list);
	
		request.getRequestDispatcher("/goods.jsp").forward(request, response);
		}else if(uri.equals("addGoods")){
			//���Ӳ���
			//ͨ��id��ȡ�ı����ֵ
			//���ַ�ת������������
			int gId=Integer.parseInt(request.getParameter("goodsId"));
			String gName=request.getParameter("goodsName");
			int gAmount =Integer.parseInt(request.getParameter("goodsAmount"));
			int gPrice =Integer.parseInt(request.getParameter("goodsPrice"));
			String gAdd =request.getParameter("goodsAdd");
			

			
			Goods goods =new Goods(gId , gName , gAmount , gPrice,gAdd);
			
			//���ӵķ���
			goodsDao.addGoods(goods);
			//�ض���listGoods
			response.sendRedirect("listGoods");
			
			
		}else if(uri.equals("deleteGoods")){
			//��ȡҪɾ����id
			int id=Integer.parseInt(request.getParameter("id"));
			goodsDao.deleteGoods(id);
			response.sendRedirect("listGoods");
		}else if(uri.equals("loadGoods")){
			//load() �����ӷ�������������
			int goodsId =Integer.parseInt(request.getParameter("id"));
			Goods goods =goodsDao.findById(goodsId);
			request.setAttribute("goods", goods);
			request.getRequestDispatcher("/loadGoods.jsp").forward(request, response);
		}else if(uri.equals("updateGoods")) {
			
			int gId=Integer.parseInt(request.getParameter("goodsId"));
			String gName=request.getParameter("goodsName");
			int gAmount =Integer.parseInt(request.getParameter("goodsAmount"));
			int gPrice =Integer.parseInt(request.getParameter("goodsPrice"));
			String gAdd =request.getParameter("goodsAdd");
			
			
			Goods goods =new Goods(gId , gName , gAmount , gPrice,gAdd);
			goodsDao.updateGoods(goods);
			response.sendRedirect("listGoods");
			
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
