package com.dlvtc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dlsp.pojo.Goods;
import com.dlvtc.util.JDBCTools;




public class GoodsDao {
	//����
		public void addGoods(Goods goods){
			Connection conn = null;
			PreparedStatement ps =null;
			try{
				conn = JDBCTools.getConnection();
				String sql ="INSERT INTO t_goods(goodsId,goodsName,goodsAmount,goodsPrice,goodsAdd) VALUES(?,?,?,?,?)";
				
				ps =conn.prepareStatement(sql);
				ps.setInt(1, goods.getGoodsId());
				ps.setString(2, goods.getGoodsName());
				ps.setInt(3, goods.getGoodsAmount());
				ps.setInt(4, goods.getGoodsPrice());
				ps.setString(5, goods.getGoodsAdd());
				ps.executeUpdate();
			}catch (SQLException e){
				e.printStackTrace();
			}finally{
				JDBCTools.closeConnection(conn, ps, null);
			}
			
		}
		//ɾ��
		public void deleteGoods(int goodsId ){
			Connection conn = null;
			PreparedStatement ps =null;
			try{
				conn = JDBCTools.getConnection();
				String sql ="DELETE FROM t_goods WHERE goodsId =?";
				
				ps =conn.prepareStatement(sql);
				ps.setInt(1, goodsId);
				ps.executeUpdate();
			}catch (SQLException e){
				e.printStackTrace();
			}finally{
				JDBCTools.closeConnection(conn, ps, null);
			}
		}
		

		//�޸�
		public void updateGoods(Goods goods){
			Connection conn = null;
			PreparedStatement ps =null;
			try{
				conn = JDBCTools.getConnection();
				String sql ="UPDATE t_goods SET goodsName=? ,goodsAmount=? ,goodsPrice=? ,goodsAdd=? WHERE goodsId=?";
				
				ps =conn.prepareStatement(sql);
				ps.setString(1, goods.getGoodsName());
				ps.setInt(2, goods.getGoodsAmount());
				ps.setInt(3, goods.getGoodsPrice());
				ps.setString(4, goods.getGoodsAdd());
				ps.setInt(5, goods.getGoodsId());
				ps.executeUpdate();
			}catch (SQLException e){
				e.printStackTrace();
			}finally{
				JDBCTools.closeConnection(conn, ps, null);
			}
		}
		
		//��ѯid
		public Goods  findById(int goodsId){
			Connection conn = null;
			PreparedStatement ps =null;
			ResultSet rs =null;
			try{
				conn = JDBCTools.getConnection();
				String sql ="SELECT goodsId,goodsName,goodsAmount,goodsPrice,goodsAdd FROM t_goods WHERE goodsId=? ";
				
				ps =conn.prepareStatement(sql);
				ps.setInt(1, goodsId);
				rs =ps.executeQuery();
				Goods goods =null;
				while(rs.next()){
					int gId=rs.getInt("goodsId");
					String gName=rs.getString("goodsName");
					int gAmount =rs.getInt("goodsAmount");
					int gPrice =rs.getInt("goodsPrice");
					String gAdd =rs.getString("goodsAdd");
					

					
					goods =new Goods(gId , gName , gAmount , gPrice,gAdd);
					return goods;
				}
			}catch (SQLException e){
				e.printStackTrace();
			}finally{
				JDBCTools.closeConnection(conn, ps, null);
			}
			return null;
			
		}
		
		//��ѯ
		public List<Goods> findAll(){
			Connection conn = null;
			PreparedStatement ps =null;
			ResultSet rs =null;
			try{
				conn = JDBCTools.getConnection();
				String sql ="SELECT goodsId,goodsName,goodsAmount,goodsPrice,goodsAdd FROM t_goods ";
				
				ps =conn.prepareStatement(sql);
				rs =ps.executeQuery();
				Goods goods =null;
				List<Goods> list =new ArrayList<Goods>();
				while(rs.next()){
					int gId=rs.getInt("goodsId");
					String gName=rs.getString("goodsName");
					int gAmount =rs.getInt("goodsAmount");
					int gPrice =rs.getInt("goodsPrice");
					String gAdd =rs.getString("goodsAdd");
					goods =new Goods(gId , gName , gAmount , gPrice,gAdd);
					
					list.add(goods);
				}
				return list;
			}catch (SQLException e){
				e.printStackTrace();
			}finally{
				JDBCTools.closeConnection(conn, ps, null);
			}
			
			return null;
			
		}

	
		
		

}
